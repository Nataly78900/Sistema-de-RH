<?php
// Detecta la página actual para marcar el link activo
$pagina_actual = basename($_SERVER['PHP_SELF']);
?>

<aside class="sidebar">

  <!-- Logo / marca -->
  <div class="sidebar-logo">
    <div class="sidebar-logo-icon">
      <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
    </div>
    <div class="sidebar-logo-text">
      <strong>Jeser Etiquetas</strong>
      <span>RRHH</span>
    </div>
  </div>

  <!-- Navegación -->
  <nav class="sidebar-nav">
    <p class="sidebar-section-label">Principal</p>

    <a href="index.php" class="sidebar-link <?= $pagina_actual === 'index.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      <span>Dashboard</span>
    </a>

    <p class="sidebar-section-label">Gestión</p>

    <a href="empleados.php" class="sidebar-link <?= $pagina_actual === 'empleados.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      <span>Empleados</span>
    </a>

    <a href="areas.php" class="sidebar-link <?= $pagina_actual === 'areas.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      <span>Áreas</span>
    </a>

    <a href="asistencias.php" class="sidebar-link <?= $pagina_actual === 'asistencias.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span>Asistencias</span>
    </a>

    <a href="reportes.php" class="sidebar-link <?= $pagina_actual === 'reportes.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
      <span>Reportes</span>
    </a>
  </nav>

  <!-- Usuario / cerrar sesión -->
  <div class="sidebar-bottom">
    <a href="login.php" class="sidebar-user" title="Cerrar sesión">
      <div class="sidebar-avatar">
        <?= strtoupper(substr($_SESSION['usuario'] ?? 'A', 0, 1)) ?>
      </div>
      <div class="sidebar-user-info">
        <strong><?= htmlspecialchars($_SESSION['usuario'] ?? 'Admin') ?></strong>
        <span>Cerrar sesión</span>
      </div>
    </a>
  </div>

</aside>
